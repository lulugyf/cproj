#include <framework.h>

#include <string>
#include <iostream>
#include <list>
#include <time.h>
#include <sstream>
#include <unistd.h>

#include "calltrace.h"

using namespace std;
#define CALLTRACEFLAG "!_@"

extern "C" {
	int udp_socket();
	void *udp_make_addr(const char *addr);
	int udp_sendto(int sd, void *addr, const char *buf, int len);
	void udp_close(int s);
	void udp_getlocaladdr(char addr[16]);
}


/*
<ͳһID> <����ID> <������ID> <������> <������> <���ÿ�ʼʱ��> <���ý���ʱ��>
<����IP> <�˿ں�> <�ֻ���> <����> <ģ�����> <�������> <�����Ϣ>
 */
struct CallInfo{
    list<string> callstack;
    const char * servicename;      //��������
    const char * bpname;        // ���BP����
    char universe_accept[128]; //ͳһ��ˮ
    int  log_flag;             // ���񿪹��Ƿ�򿪣� 1-�ǣ� 0-��
    int  log_handle;          // fd of udp socket
    void *log_path;            // sockaddr_in *addr, generate by udp_make_addr, and must free outer
    int  callid_seed;
    char login_no[64];
    char op_code[8];
    char phone_no[64];
    char localaddr[16];
    const char * push(const char *callid);
    void pop();
};


TCtrlInfoEx2::TCtrlInfoEx2() {
	

    memset(this, 0, sizeof(TCtrlInfoEx2));
    CallInfo *c = new CallInfo();
    memcpy(__flag1, CALLTRACEFLAG, 4);
    c->log_path = NULL;
    c->log_handle = -1;
    reserve1 = c;
}

TCtrlInfoEx2::~TCtrlInfoEx2(){
	

    CallInfo *c = (CallInfo *)reserve1;
    
    
   	if( c == NULL  ) return ;
   		
    if(c->log_path != NULL)
    	free(c->log_path);
    if(c->log_handle != -1)
    	udp_close(c->log_handle);
    	 
    delete c;

}

const char *TCtrlInfoEx2::getServiceName(){
	CallInfo *c = (CallInfo *)reserve1;
	return c->servicename;
}

const char *TCtrlInfoEx2::getBPName(){
	CallInfo *c = (CallInfo *)reserve1;
	return c->bpname;
}

bool TCtrlInfoEx2::checkStruct(){
	if(memcmp(__flag1, CALLTRACEFLAG, sizeof(CALLTRACEFLAG)) == 0)
		return true;
	return false;
}


static char* uGetStrByName(const utype* pu, char* buf, int bufSize, const char* name)
{
    UPOS p;
    memset(buf, 0, bufSize);
    //���ҵ�ǰutype���Ƿ�������Ϊname�Ľڵ㣬������򷵻ؽڵ�ֵ
    if(UPOS_END !=(p = utFind(pu, name)))
    {
		switch(pu->ppe[p]->type)
		{
			case U_INT:snprintf(buf, bufSize - 1, "%d", utGetInt(pu, name, p));break;
			case U_LONG:snprintf(buf, bufSize - 1, "%ld", utGetLong(pu, name, p));break;
			case U_DOUBLE:snprintf(buf, bufSize - 1, "%0.2f", utGetDouble(pu, name, p));break;
			case U_STRING:snprintf(buf, bufSize - 1, "%s", utGetStr(pu, name, p));break;
			default:strcpy(buf, "");break;
		}
		return buf;
	}

    char sUtypeNodeName[127 + 1];
    uAutoPtr uTmp(uInit(0));
    uTmp = utClone(pu);
    int iLen = uTmp->cnt;

    for(int i = 0; i < iLen; i ++)
    {
        //���Ȱ��������µ�˳��ȡutype��ǰĿ¼�����нڵ㣬
        //���жϽڵ��Ƿ�Ϊutype��Ϊutype�����utype��Ȼ��ص�����
        memset(sUtypeNodeName, 0, sizeof(sUtypeNodeName));
        strcpy(sUtypeNodeName, utGetName(pu, i));
        //printf("*****************sUtypeNodeName=[%s]***********************\n", sUtypeNodeName);
        int uTypeType = utGetType(pu, sUtypeNodeName);
        if(U_STRUCT == uTypeType)
        {
            uGetStrByName(utGetStruct(pu, sUtypeNodeName), buf, bufSize, name);
            if('\0' != buf[0])
            {
                return buf;
            }
        }
    }
    return buf;
}

static void timestr14(struct timeval *t, char *str)
{
	struct tm *tm;
	tm = localtime(&t->tv_sec);
	sprintf(str, "%04d%02d%02d%02d%02d%02d",
			tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
			tm->tm_hour, tm->tm_min, tm->tm_sec);
}

/*
 *
�����ļ�crm.cfg ��������,�˵��˼��
[E2E_LOG]
e2e_sendlog_flag=1
svc_${servicename}=1(���񿪹�),1(ͳһ��ˮ����)
uni_accept_path=COMMON_INFO.TRACE_ID
log_path=udp://127.0.0.1:7788
 */
void TCtrlInfoEx2::init(const char *servicename, const char *bpname, const utype *uin){
	CallInfo *c = (CallInfo *)reserve1;
	
	char temp[128];
	char kgvalue[20];

		
	memset(temp,0,sizeof(temp));
	memset(kgvalue,0,sizeof(kgvalue));
	
	c->servicename = servicename;
	c->bpname = bpname;
	
	//������ÿ��أ� �Լ���ȡͳһ��ˮ����	
	
	//�ж��ܿ����Ƿ��
	if(strcmp(cfgGetStr("E2E_LOG", "e2e_sendlog_flag"), "1") != 0){
				c->log_flag = 0;
				return;
	}
	
	//�ܿ��ش򿪣��������ֿ����Ƿ��
	sprintf(temp, "svc_%s", servicename);
	strcpy(kgvalue,cfgGetStr("E2E_LOG", temp));
	
	//���񿪹��Ƿ��
	if( kgvalue[0] == '1' ){
		c->log_flag = 1;
	}else{
		c->log_flag = 0;
		return;
	}

	//��ȡͳһ��ˮ�������浽CallInfo �ṹ����
	const char *uni_accept_path = cfgGetStr("E2E_LOG", "uni_accept_path");
	if(uni_accept_path[0] == 0){
		c->log_flag = 0;
		return;
	}
	try{
		 char *uniaccept = NULL;
		try{
			uniaccept = utGetStrByPath(uin, uni_accept_path);
			strcpy(c->universe_accept, uniaccept);
		}catch(uException &ue){
		}
		
		//ͳһ��ˮ�����Ƿ��
		if( (uniaccept==0 || uniaccept[0] == 0 ) && kgvalue[2] != '1' )
			c->log_flag = 0;
		else if( (uniaccept==0 || uniaccept[0] == 0) && kgvalue[2] == '1' )
		{
			char _t11[15]={"\0"};
			struct timeval t11;
			
			gettimeofday(&t11, NULL);
			timestr14(&t11, _t11);		
			pid_t pid = getpid();
			pid = pid >999999?0:pid;//������6λ������ͳһ��ˮ�ĳ���
			srand( (unsigned int)(time(0)+pid) );	
			int irand = (rand()%900000)+ 100000;
			pid = pid==0?	irand:pid;
			 
			//��������ͳһ��ˮ
			sprintf(c->universe_accept,"90*%s*tuxd*tux%06ld*%d",_t11,pid,irand);	
			c->universe_accept[40]='\0';
			
			strcpy(temp, "90000000991");
		}		
		else
			strcpy(temp, utGetStrByPath(uin, "COMMON_INFO.CALL_ID"));
		
		 
		
	}catch(uException &ue){
		L4C_DEBUG("TCtrlInfoEx2 err or ");
		L4C_DEBUG("===get path:%s failed code:%d msg:%s", uni_accept_path, ue.errCode, ue.errMsg);
		//strcpy(c->universe_accept, "<unknown>");
		c->log_flag = 0;
	}
	
	if( c->log_flag == 0 )
		 return;

	//����UDP socket�Լ��������ж�ȡ����˵�ַ
	const char *log_path = cfgGetStr("E2E_LOG", "log_path");
	c->log_handle = udp_socket();
	c->log_path = udp_make_addr(log_path);
	udp_getlocaladdr(c->localaddr);

	/*
	uGetStrByName(uin, c->login_no, sizeof(c->login_no), "LOGIN_NO");
	uGetStrByName(uin, c->phone_no, sizeof(c->phone_no), "PHONE_NO");
	uGetStrByName(uin, c->op_code, sizeof(c->op_code), "OP_CODE");
	*/
	
	strcpy(c->login_no,"null");
	strcpy(c->phone_no,"null");
	strcpy(c->op_code,"null");
	
	c->push(temp);
}





#include <uuid/uuid.h>
const char * CallInfo::push(const char *callid){
	const char *p = NULL;

	if(callstack.size() > 0)
		p = callstack.back().c_str();
	callstack.push_back( callid );
	return p;
}

void CallInfo::pop(){
	callstack.pop_back();
}



static void timestr(struct timeval *t, char *str)
{
	struct tm *tm;
	tm = localtime(&t->tv_sec);
	sprintf(str, "%04d-%02d-%02d% 02d:%02d:%02d.%03d",
			tm->tm_year+1900, tm->tm_mon+1, tm->tm_mday,
			tm->tm_hour, tm->tm_min, tm->tm_sec, t->tv_usec/1000);
}

void EntryRecord::setCode(long c){
	code = c;
}
void EntryRecord::setMsg(const char *m) {
	errmsg = m;
}

void EntryRecord::setIn(const utype *pin){ 	this->pin = pin; }
void EntryRecord::setIn(const char *pin){ 	this->s_pin = pin; }

void EntryRecord::setOut(const utype *pout){ this->pout = pout; }
void EntryRecord::setOut(const char *pout){ this->s_pout = pout; }

EntryRecord::EntryRecord(const char *func, TCtrlInfo *tinfo){

	if(!((TCtrlInfoEx2 *)tinfo)->checkStruct())
		return;
		
	CallInfo *x = (CallInfo *)(((TCtrlInfoEx2 *)tinfo)->reserve1);
	
	CallInfo *ci = NULL;
	if( x == NULL ){ 
			ci = x;
			cii = x;
			return ;
	}

	ci = x;
	cii = ci;
	
	if (ci == NULL)
		return;
		
  if(ci->log_flag == 0)
        return;		
		
	funcname = func;
	gettimeofday(&t1, NULL);
	code = 0;

	// ���� callid
    uuid_t buf;
    uuid_generate(buf);
    uuid_unparse(buf, callid);
	//sprintf(callid, "%04d", ++ci->callid_seed);
	errmsg = NULL;
	pin = NULL;
	pout = NULL;
	s_pin = NULL;
	s_pout = NULL;
	callid_p = ci->push(callid);

}

EntryRecord::~EntryRecord(){

	
	if(cii == NULL)
		return;

		
	CallInfo * ci = (CallInfo *)cii;
	
  if(ci->log_flag == 0)
        return;		
     	
		ci->pop(); 

  			      	
	gettimeofday(&t2, NULL);
	char _t1[32], _t2[32];
	timestr(&t1, _t1);
	timestr(&t2, _t2);
	stringstream ss;
	
	ss <<ci->universe_accept<<"~!~"<<callid<<"~!~";
	
	if( callid_p!=NULL )
		ss << callid_p ;
	else
		ss << "" ;
		
		ss<<"~!~xxx~!~" <<ci->servicename <<"~!~";
		 
		ss <<"B001~!~null~!~" <<funcname<<"~!~";
	
	
	ss << _t1 << "~!~" << _t2 << "~!~" << ci->localaddr << "~!~" << 0<<"~!~"<<"null"<< "~!~";
	ss <<"null"<< "~!~"<<ci->phone_no<<"~!~"<<ci->login_no<<"~!~";
	ss << "null~!~" << ci->op_code<<"~!~"<<code<<"~!~";
		
	if( errmsg!=NULL && errmsg[0]!='\0' ){
		ss<<errmsg;
	}else{
		ss<<"null";
	}	
		
	ss<< "~!~";
	
	//ֻ���������ڵ��������
	if( ci->servicename != NULL && funcname!=NULL && ci->servicename[0] == 's' 
		&& strcmp(ci->servicename,funcname) == 0 ){
			if(s_pin != NULL){
				ss << s_pin << "~!~";
			}else if(pin == NULL){
				ss << "NULL~!~";
			}else{
				char *xmlstr = uUType2Xml(pin, "ROOT");
				if(xmlstr != NULL){
					ss << xmlstr << "~!~";
					free(xmlstr);
				}
			}			
			
		}
	
	ss<<"NULL"<<"~!~";
	
	
 /*
	if(s_pin != NULL){
		ss << s_pin << "~!~";
	}else if(pin == NULL){
		ss << "null~!~";
	}else{
		char *xmlstr = uUType2Xml(pin, "ROOT");
		if(xmlstr != NULL){
			ss << xmlstr << "~!~";
			free(xmlstr);
		}
	}
 
 ss<<"null"<<"~!~";
 
 
	if(s_pout != NULL){
		ss << s_pout << "~!~";
	}else if(pout == NULL){
		ss << "null~!~";
	}else{
		char *xmlstr = uUType2Xml(pout, "ROOT");
		if(xmlstr != NULL){
			ss << xmlstr << "~!~";
			free(xmlstr);
		}
	}		
	*/
		 
	//L4C_DEBUG("send flume: %s",	ss.str().c_str());
	
	udp_sendto(ci->log_handle, ci->log_path, ss.str().c_str(), ss.str().length());
	/*snprintf(temp, sizeof(temp)-1, "%s\t%s\t%s\t%s\t[5]%s\t%s\t%s\t%s\t[9]%d\t%s\t%s\t%s\t[13]%d\t%s",
			ci->universe_accept, callid, callid_p, "xxx" ci->servicename, _t1, _t2,
			ci->localaddr, 0, ci->phone_no, ci->login_no, ci->op_code, code, errmsg==NULL?"":errmsg);
	udp_sendto(ci->log_handle, ci->log_path, temp, strlen(temp)); 
	printf("--func[%s] callid[%s] parentcallid[%s] time[%ld] code[%d]\n",
		funcname, callid, callid_p==NULL?"<nil>":callid_p,
		(t2.tv_sec-t1.tv_sec)*1000 + (t2.tv_usec-t1.tv_usec)/1000, code);
*/
}

// need a macro to use it
//#define CALLBP(bpname, uInParam, ctrlInfo) __CALLBP(bpname, #bpname, uInParam, ctrlInfo)
utype* __CALLBP(TUtypeFuncPtr bpfunc, const char *bpname, const utype *uInParam, TCtrlInfo *ctrlInfo){
     

	if(!((TCtrlInfoEx2 *)ctrlInfo)->checkStruct()){
		return bpfunc(uInParam, ctrlInfo); //����δʹ�� TCtrlInfoEx2 �ṹ��ԭ�д��루��̨���̣�
	}
	CallInfo *x = (CallInfo *)(((TCtrlInfoEx2 *)ctrlInfo)->reserve1);
	if(x->log_flag != 1)
		return bpfunc(uInParam, ctrlInfo); //��־�أ�ֱ�ӵ��ã����ߺ�ߵĴ�����

    if(bpname == NULL)
        bpname = ((TCtrlInfoEx2 *)ctrlInfo)->getServiceName();

	
    EntryRecord __e(bpname, ctrlInfo );
    
    
    __e.setIn(uInParam);
    try{
    	utype *ret = bpfunc(uInParam, ctrlInfo);
    	__e.setOut(ret);
    	
        return ret;
    } catch (uException& err) {
		__e.setCode(303 * 1000000 + err.errCode);
		__e.setMsg(err.errMsg);
		throw err;
	} catch (otl_exception& otlErr) { // intercept OTL exceptions
		__e.setCode(302 * 1000000 + abs(otlErr.code));
		//snprintf(retMsg, sizeof(retMsg) - 1, "DBERR ����%s : %s : %s",
		//		otlErr.msg, otlErr.stm_text, otlErr.var_info);
		__e.setMsg((const char *)otlErr.msg);
		throw otlErr;
	} catch (appException& appErr) {
		__e.setCode(appErr.errCode);
		__e.setMsg(appErr.errMsg);
		throw appErr;
	} catch (std::exception& err) {
		__e.setCode(301 * 1000000);
		__e.setMsg(err.what());
		throw err;
	} catch (...) {
		__e.setCode(300 * 1000000);
		__e.setMsg("δ֪��������ϵϵͳ����Ա!");
		throw;
	}
	return NULL;
}
